package dev.vgl.client;

import java.util.*;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.*;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import org.lwjgl.input.Keyboard;

/** Modules that have real behaviour. Every other module in Catalog is a configurable placeholder. */
public class Impl {

    public static class Clicks {
        static final ArrayDeque<Long> L = new ArrayDeque<Long>(), R = new ArrayDeque<Long>();
        static void add(boolean left) { (left ? L : R).addLast(System.currentTimeMillis()); }
        static int cps(ArrayDeque<Long> q) { long n = System.currentTimeMillis(); while (!q.isEmpty() && n - q.peekFirst() > 1000) q.pollFirst(); return q.size(); }
        public static int l() { return cps(L); }
        public static int r() { return cps(R); }
    }

    // ---------------- PvP & combat ----------------
    public static class Cps extends HudModule {
        Cps(String n, String c, String[] p) { super(n, c, p); }
        protected List<String> lines() {
            List<String> o = new ArrayList<String>(); boolean l = b("Left Click Display"), r = b("Right Click Display");
            if (mode("Layout") == 0) { String s = (l ? "" + Clicks.l() : "") + (l && r ? " | " : "") + (r ? "" + Clicks.r() : ""); o.add(s + " CPS"); }
            else { if (l) o.add("L: " + Clicks.l() + " CPS"); if (r) o.add("R: " + Clicks.r() + " CPS"); }
            return o;
        }
    }

    public static class Crosshair extends Module {
        Crosshair(String n, String c, String[] p) { super(n, c, p); implemented = true; }
        static void bar(float x, float y, float w, float h, int col, int out) { Draw.rect(x - 1, y - 1, w + 2, h + 2, out); Draw.rect(x, y, w, h, col); }
        public void onOverlayPre(RenderGameOverlayEvent.Pre e) {
            if (e.type != RenderGameOverlayEvent.ElementType.CROSSHAIRS) return;
            e.setCanceled(true);
            if (b("Hide while Spectating") && mc.field_71442_b != null && mc.field_71442_b.func_78747_a()) return;
            float cx = e.resolution.func_78326_a() / 2f, cy = e.resolution.func_78328_b() / 2f, tgt = 0;
            if (b("Dynamic Crosshair") && mc.field_71439_g != null) {
                double v = mc.field_71439_g.field_70159_w * mc.field_71439_g.field_70159_w + mc.field_71439_g.field_70179_y * mc.field_71439_g.field_70179_y;
                tgt = v > 0.0004 ? 4 : 0; if (mc.field_71439_g.func_70051_ag()) tgt = 6;
            }
            float exp = Anim.get(this, tgt, 15f);
            float gap = (float) n("Gap Size") + exp, w = (float) n("Width"), h = (float) n("Height"), t = (float) n("Thickness");
            int col = c("Color"), out = c("Outline Color");
            switch (mode("Crosshair Type")) {
                case 0:
                    bar(cx - gap - w, cy - t / 2, w, t, col, out); bar(cx + gap, cy - t / 2, w, t, col, out);
                    bar(cx - t / 2, cy - gap - h, t, h, col, out); bar(cx - t / 2, cy + gap, t, h, col, out); break;
                case 1: bar(cx - t, cy - t, t * 2, t * 2, col, out); break;
                case 2: Draw.ring(cx, cy, gap + w / 2, out, t + 2); Draw.ring(cx, cy, gap + w / 2, col, t); break;
                default:
                    Draw.line(cx - w, cy + h / 2, cx, cy - h / 2, t + 2, out); Draw.line(cx + w, cy + h / 2, cx, cy - h / 2, t + 2, out);
                    Draw.line(cx - w, cy + h / 2, cx, cy - h / 2, t, col); Draw.line(cx + w, cy + h / 2, cx, cy - h / 2, t, col);
            }
        }
    }

    public static class ArmorStatus extends HudModule {
        ArmorStatus(String n, String c, String[] p) { super(n, c, p); }
        public void onRender(ScaledResolution sr, float pt) {
            if (mc.field_71439_g == null) return;
            List<ItemStack> l = new ArrayList<ItemStack>();
            if (b("Toggle Held Item") && mc.field_71439_g.func_70694_bm() != null) l.add(mc.field_71439_g.func_70694_bm());
            if (b("Toggle Armor")) for (int i = 3; i >= 0; i--) { ItemStack s = mc.field_71439_g.field_71071_by.field_70460_b[i]; if (s != null) l.add(s); }
            float sc = (float) n("Icon Scaling");
            GlStateManager.func_179094_E(); GlStateManager.func_179109_b(px(sr), py(sr), 0); GlStateManager.func_179152_a(sc, sc, 1);
            for (int i = 0; i < l.size(); i++) {
                ItemStack s = l.get(i); int yy = i * 18;
                GlStateManager.func_179091_B(); RenderHelper.func_74520_c();
                mc.func_175599_af().func_180450_b(s, 0, yy);
                RenderHelper.func_74518_a(); GlStateManager.func_179101_C(); GlStateManager.func_179147_l();
                if (s.func_77984_f() && s.func_77958_k() > 0) {
                    int left = s.func_77958_k() - s.func_77952_i(), pct = left * 100 / s.func_77958_k(); String t = "";
                    if (b("Display Durability")) t += left;
                    if (b("Display Percentage")) t += (t.isEmpty() ? "" : " ") + pct + "%";
                    Draw.text(t, 20, yy + 5, pct <= n("Damage Threshold Warning") ? 0xFFFF5555 : textColor(), true);
                }
            }
            GlStateManager.func_179121_F();
        }
    }

    public static class Keystrokes extends HudModule {
        Keystrokes(String n, String c, String[] p) { super(n, c, p); }
        void key(String id, float x, float y, float w, float h, String label, boolean down) {
            float t = Anim.get(id, down ? 1 : 0, 3000f / Math.max(30f, (float) n("Fade Delay")));
            int base = Draw.lerp(Draw.mulA(c("Default Key Color"), .38f), Draw.mulA(c("Key Click Color"), .6f), t);
            Draw.rrect(x, y, w, h, 5, Draw.mulA(base, 1f), Draw.mulA(base, .7f));
            Draw.stroke(x, y, w, h, 5, Draw.argb(.7f, 255, 255, 255), Draw.argb(.15f, 255, 255, 255), 1f);
            Draw.ctext(label, x + w / 2, y + h / 2 - 4, Draw.lerp(textColor(), 0xFF101010, t * .85f), false);
        }
        public void onRender(ScaledResolution sr, float pt) {
            float x = px(sr), y = py(sr);
            if (b("Display WASD")) {
                key("kW", x + 24, y, 22, 22, "W", mc.field_71474_y.field_74351_w.func_151470_d());
                key("kA", x, y + 24, 22, 22, "A", mc.field_71474_y.field_74370_x.func_151470_d());
                key("kS", x + 24, y + 24, 22, 22, "S", mc.field_71474_y.field_74368_y.func_151470_d());
                key("kD", x + 48, y + 24, 22, 22, "D", mc.field_71474_y.field_74366_z.func_151470_d());
                y += 48;
            }
            if (b("Mouse Button Display")) {
                key("kL", x, y, 34, 22, b("CPS Overlay") ? Clicks.l() + " cps" : "LMB", mc.field_71474_y.field_74312_F.func_151470_d());
                key("kR", x + 36, y, 34, 22, b("CPS Overlay") ? Clicks.r() + " cps" : "RMB", mc.field_71474_y.field_74313_G.func_151470_d());
                y += 24;
            }
            if (b("Spacebar Display")) key("kSp", x, y, 70, 14, "----", mc.field_71474_y.field_74314_A.func_151470_d());
        }
    }

    public static class ReachDisplay extends HudModule {
        double last = -1; long when;
        ReachDisplay(String n, String c, String[] p) { super(n, c, p); }
        public void onAttack(AttackEntityEvent e) {
            if (e.entityPlayer != mc.field_71439_g) return;
            Entity t = e.target; AxisAlignedBB bb = t.func_174813_aQ();
            double ex = mc.field_71439_g.field_70165_t, ey = mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e(), ez = mc.field_71439_g.field_70161_v;
            double dx = Math.max(Math.max(bb.field_72340_a - ex, 0), ex - bb.field_72336_d), dy = Math.max(Math.max(bb.field_72338_b - ey, 0), ey - bb.field_72337_e), dz = Math.max(Math.max(bb.field_72339_c - ez, 0), ez - bb.field_72334_f);
            last = Math.sqrt(dx * dx + dy * dy + dz * dz); when = System.currentTimeMillis();
        }
        protected List<String> lines() {
            if (!b("Display Hit Distance") || last < 0 || System.currentTimeMillis() - when > n("Timeout Reset") * 1000) return null;
            String f = find("Text Format").modeName();
            return Arrays.asList(f.replace("%s", String.format("%." + (int) n("Text Decimal Length") + "f", last)));
        }
        protected boolean bg() { return b("Background Shadow"); }
    }

    public static class ToggleSprintSneak extends HudModule {
        boolean sprintOn, sneakOn, lastSprint, lastSneak;
        ToggleSprintSneak(String n, String c, String[] p) { super(n, c, p); }
        public void onTick() {
            if (mc.field_71439_g == null || mc.field_71462_r != null) return;
            KeyBinding sn = mc.field_71474_y.field_74311_E, sp = mc.field_71474_y.field_151444_V;
            boolean snDown = Keyboard.isKeyDown(sn.func_151463_i()), spDown = Keyboard.isKeyDown(sp.func_151463_i());
            if (b("Toggle Sneak")) { if (snDown && !lastSneak) sneakOn = !sneakOn; KeyBinding.func_74510_a(sn.func_151463_i(), sneakOn || snDown); }
            if (b("Toggle Sprint")) { if (spDown && !lastSprint) sprintOn = !sprintOn; KeyBinding.func_74510_a(sp.func_151463_i(), sprintOn || spDown); }
            lastSneak = snDown; lastSprint = spDown;
        }
        public void onDisable() { sprintOn = sneakOn = false; }
        protected List<String> lines() {
            if (!b("HUD Indicator Status")) return null; List<String> l = new ArrayList<String>();
            if (sneakOn) l.add("[Sneaking (Toggled)]"); else if (mc.field_71439_g != null && mc.field_71439_g.func_70093_af()) l.add("[Sneaking (Held)]");
            if (sprintOn) l.add("[Sprinting (Toggled)]"); else if (mc.field_71439_g != null && mc.field_71439_g.func_70051_ag()) l.add("[Sprinting (Held)]");
            return l;
        }
    }

    public static class Potions extends HudModule {
        static final Gui G = new Gui(); static final ResourceLocation INV = new ResourceLocation("textures/gui/container/inventory.png");
        Potions(String n, String c, String[] p) { super(n, c, p); }
        public void onRender(ScaledResolution sr, float pt) {
            if (mc.field_71439_g == null) return;
            List<PotionEffect> l = new ArrayList<PotionEffect>(mc.field_71439_g.func_70651_bq()); if (l.isEmpty()) return;
            switch (mode("Sorting Order")) {
                case 0: Collections.sort(l, new Comparator<PotionEffect>() { public int compare(PotionEffect a, PotionEffect o) { return o.func_76459_b() - a.func_76459_b(); } }); break;
                case 1: Collections.sort(l, new Comparator<PotionEffect>() { public int compare(PotionEffect a, PotionEffect o) { return I18n.func_135052_a(a.func_76453_d()).compareTo(I18n.func_135052_a(o.func_76453_d())); } }); break;
                default: Collections.sort(l, new Comparator<PotionEffect>() { public int compare(PotionEffect a, PotionEffect o) { return o.func_76458_c() - a.func_76458_c(); } });
            }
            boolean horiz = mode("Layout") == 1, compact = b("Compact Mode"), icon = !b("Hide Icon"), nm = !b("Hide Name");
            float x = px(sr), y = py(sr), h = compact ? 14 : 22;
            for (PotionEffect e : l) {
                String name = I18n.func_135052_a(e.func_76453_d()) + (e.func_76458_c() > 0 ? " " + (e.func_76458_c() + 1) : ""), time = b("Countdown Clock") ? Potion.func_76389_a(e) : "";
                boolean flash = e.func_76459_b() < n("Warning Flash Duration") * 20 && (System.currentTimeMillis() / 250) % 2 == 0;
                int col = flash ? 0xFFFF5555 : textColor();
                String l1 = nm ? name : "", l2 = time; String one = (l1 + (compact && !l1.isEmpty() && !l2.isEmpty() ? " " : "") + (compact ? l2 : "")).trim();
                float tw = compact ? Draw.w(one) : Math.max(Draw.w(l1), Draw.w(l2)), wid = tw + 8 + (icon ? h - 2 : 0);
                Draw.glass(x, y, wid, h, 5, .85f);
                float tx = x + 4;
                Potion p = Potion.field_76425_a[e.func_76456_a()];
                if (icon && p != null && p.func_76400_d()) {
                    int idx = p.func_76392_e(); float s = (h - 2) / 18f;
                    mc.func_110434_K().func_110577_a(INV); GlStateManager.func_179131_c(1, 1, 1, 1); GlStateManager.func_179147_l();
                    GlStateManager.func_179094_E(); GlStateManager.func_179109_b(x + 1, y + 1, 0); GlStateManager.func_179152_a(s, s, 1);
                    G.func_73729_b(0, 0, idx % 8 * 18, 198 + idx / 8 * 18, 18, 18); GlStateManager.func_179121_F();
                }
                if (icon) tx += h - 2;
                if (compact) Draw.text(one, tx, y + 3, col, true);
                else { Draw.text(l1, tx, y + 3, col, true); Draw.text(l2, tx, y + 12, col, true); }
                if (horiz) x += wid + 3; else y += h + 3;
            }
        }
    }

    public static class Hitboxes extends Module {
        Hitboxes(String n, String c, String[] p) { super(n, c, p); implemented = true; }
        public void onTick() { mc.func_175598_ae().func_178629_b(b("Show Hitbox")); }
        public void onDisable() { mc.func_175598_ae().func_178629_b(false); }
    }

    // ---------------- Performance & utility ----------------
    public static class Fps extends HudModule {
        long last; int fps;
        Fps(String n, String c, String[] p) { super(n, c, p); }
        protected List<String> lines() {
            if (System.currentTimeMillis() - last >= n("Update Interval (MS)")) { fps = net.minecraft.client.Minecraft.func_175610_ah(); last = System.currentTimeMillis(); }
            return Arrays.asList(b("Show FPS Text") ? fps + " FPS" : "" + fps);
        }
    }

    public static class Coords extends HudModule {
        Coords(String n, String c, String[] p) { super(n, c, p); }
        protected List<String> lines() {
            if (mc.field_71439_g == null) return null; List<String> o = new ArrayList<String>(); double x = mc.field_71439_g.field_70165_t, y = mc.field_71439_g.field_70163_u, z = mc.field_71439_g.field_70161_v;
            boolean dec = mode("Format Style") == 1, stack = mode("Format Style") == 2, comp = b("Compact Mode");
            String fx = dec ? String.format("%.1f", x) : "" + MathHelper.func_76128_c(x), fy = dec ? String.format("%.1f", y) : "" + MathHelper.func_76128_c(y), fz = dec ? String.format("%.1f", z) : "" + MathHelper.func_76128_c(z);
            if (stack) { o.add("X: " + fx); o.add("Y: " + fy); o.add("Z: " + fz); } else o.add(comp ? fx + " " + fy + " " + fz : "XYZ: " + fx + " / " + fy + " / " + fz);
            if (b("Direction Heading")) { String d = mc.field_71439_g.func_174811_aO().func_176610_l(); o.add("Facing: " + Character.toUpperCase(d.charAt(0)) + d.substring(1)); }
            if (b("Biome Display") && mc.field_71441_e != null) o.add("Biome: " + mc.field_71441_e.func_180494_b(mc.field_71439_g.func_180425_c()).field_76791_y);
            return o;
        }
    }

    public static class Memory extends HudModule {
        Memory(String n, String c, String[] p) { super(n, c, p); }
        int pct;
        protected List<String> lines() {
            Runtime r = Runtime.getRuntime(); long max = r.maxMemory(), total = r.totalMemory(), used = total - r.freeMemory(); pct = (int) (used * 100 / max);
            long cap = b("Display Allocated RAM") ? total : max;
            return Arrays.asList("Mem: " + used / 1048576 + (b("Max RAM Metric") ? "/" + cap / 1048576 : "") + " MB" + (b("Percentage Output") ? " (" + pct + "%)" : ""));
        }
        protected int color() { return pct >= n("Color Warning Threshold") ? 0xFFFF5555 : textColor(); }
    }

    public static class AngleMod extends HudModule {
        AngleMod(String n, String c, String[] p) { super(n, c, p); }
        protected List<String> lines() {
            if (mc.field_71439_g == null) return null; List<String> o = new ArrayList<String>();
            float yaw = MathHelper.func_76142_g(mc.field_71439_g.field_70177_z), pit = mc.field_71439_g.field_70125_A; boolean r = b("Round to Nearest Int");
            if (b("Show Pitch")) o.add("Pitch: " + (r ? "" + Math.round(pit) : String.format("%.1f", pit)));
            if (b("Show Yaw")) o.add("Yaw: " + (r ? "" + Math.round(yaw) : String.format("%.1f", yaw)));
            return o;
        }
    }

    public static class DirectionHud extends HudModule {
        static final String[] CARD = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
        DirectionHud(String n, String c, String[] p) { super(n, c, p); }
        public void onRender(ScaledResolution sr, float pt) {
            if (mc.field_71439_g == null) return;
            float bearing = (MathHelper.func_76142_g(mc.field_71439_g.field_70177_z) + 180f + 360f) % 360f; int col = c("Color Theme");
            float x = px(sr), y = py(sr);
            if (mode("Style") == 1) {
                String t = CARD[(int) ((bearing + 22.5f) / 45f) % 8] + (b("Show Degrees") ? " " + (int) bearing + "\u00b0" : "");
                Draw.glass(x, y, Draw.w(t) + 12, 16, 6, .9f); Draw.text(t, x + 6, y + 4, col, true); return;
            }
            float span = (float) n("Horizontal Screen Span"), cx = x + span / 2, ppd = span / 180f;
            Draw.glass(x, y, span, 24, 7, .9f);
            for (int m = 0; m < 360; m += 15) {
                float rel = MathHelper.func_76142_g(m - bearing); if (Math.abs(rel) > 85) continue;
                float mx = cx + rel * ppd, a = 1f - Math.abs(rel) / 90f;
                if (m % 45 == 0) Draw.ctext(CARD[m / 45], mx, y + 4, Draw.mulA(col, a), true); else Draw.rect(mx, y + 14, 1, 5, Draw.mulA(col, a * .7f));
            }
            if (b("Marker Visibility")) Draw.rect(cx - .5f, y + 1, 1, 5, 0xFFFFFFFF);
            if (b("Show Degrees")) Draw.ctext("" + (int) bearing + "\u00b0", cx, y + 27, col, true);
        }
    }

    public static class Fullbright extends Module {
        float old; boolean addedNv;
        Fullbright(String n, String c, String[] p) { super(n, c, p); implemented = true; }
        public void onEnable() { old = mc.field_71474_y.field_74333_Y; }
        public void onDisable() { mc.field_71474_y.field_74333_Y = old; stopNv(); }
        void stopNv() { if (addedNv && mc.field_71439_g != null) mc.field_71439_g.func_70618_n(Potion.field_76439_r.field_76415_H); addedNv = false; }
        public void onTick() {
            mc.field_71474_y.field_74333_Y = (float) (n("Brightness Level") / 100.0);
            if (b("Night Vision Toggle") && mc.field_71439_g != null) { if (!mc.field_71439_g.func_70644_a(Potion.field_76439_r)) { mc.field_71439_g.func_70690_d(new PotionEffect(Potion.field_76439_r.field_76415_H, 100000, 0)); addedNv = true; } }
            else stopNv();
        }
    }

    public static class Fov extends Module {
        Fov(String n, String c, String[] p) { super(n, c, p); implemented = true; }
        public void onFov(FOVUpdateEvent e) {
            float f = e.newfov;
            if (!b("Dynamic FOV Toggle")) f = 1f;
            else {
                float m = 1f;
                if (e.entity.func_70051_ag()) m *= (float) n("Sprint FOV Multiplier");
                if (e.entity.func_70660_b(Potion.field_76424_c) != null) m *= (float) n("Speed Potion FOV Multiplier");
                if (e.entity.func_70660_b(Potion.field_76421_d) != null) m *= (float) n("Slowness FOV Multiplier");
                f = 1f + (f - 1f) * m;
            }
            e.newfov = Math.min(f, (float) n("Static FOV Cap"));
        }
    }

    public static class Zoom extends Module {
        boolean zooming, prevSmooth; float zf = 1f;
        Zoom(String n, String c, String[] p) { super(n, c, p); implemented = true; }
        public void onTick() {
            boolean k = org.lwjgl.input.Keyboard.isKeyDown(VgLClient.ZOOM.func_151463_i()) && mc.field_71462_r == null;
            if (k && !zooming) prevSmooth = mc.field_71474_y.field_74326_T;
            if (b("Cine Camera Toggle")) { if (k) mc.field_71474_y.field_74326_T = true; else if (zooming) mc.field_71474_y.field_74326_T = prevSmooth; }
            zooming = k; float t = k ? (float) (1.0 / n("Scroll Wheel Zoom Factor")) : 1f;
            zf = b("Smooth Camera Interpolation") ? zf + (t - zf) * .3f : t;
        }
        public void onMouse(MouseEvent e) {
            if (!zooming || e.dwheel == 0) return;
            Setting s = find("Scroll Wheel Zoom Factor"); s.n = Math.max(s.min, Math.min(s.max, s.n * (e.dwheel > 0 ? 1.15 : 1 / 1.15))); e.setCanceled(true);
        }
        public void onFov(FOVUpdateEvent e) { e.newfov *= zf; }
        public void onDisable() { zf = 1f; zooming = false; }
    }

    public static class MenuBlur extends Module {
        boolean loaded;
        MenuBlur(String n, String c, String[] p) { super(n, c, p); implemented = true; }
        public void onTick() {
            boolean want = mc.field_71441_e != null && mc.field_71462_r != null && !(mc.field_71462_r instanceof ClickGui) && !(mc.field_71462_r instanceof GuiChat) && n("GUI Background Blur Intensity") > 0;
            if (want && !loaded) { try { mc.field_71460_t.func_175069_a(new ResourceLocation("shaders/post/blur.json")); loaded = true; } catch (Exception ex) { loaded = true; } }
            else if (!want && loaded && !(mc.field_71462_r instanceof ClickGui)) { if (mc.field_71460_t.func_147702_a()) mc.field_71460_t.func_181022_b(); loaded = false; }
        }
        public void onDisable() { if (loaded && mc.field_71460_t.func_147702_a()) mc.field_71460_t.func_181022_b(); loaded = false; }
    }

    // ---------------- Interface / QoL ----------------
    public static class BossBar extends Module {
        BossBar(String n, String c, String[] p) { super(n, c, p); implemented = true; }
        public void onOverlayPre(RenderGameOverlayEvent.Pre e) { if (e.type == RenderGameOverlayEvent.ElementType.BOSSHEALTH && b("Hide Boss Bar")) e.setCanceled(true); }
    }

    public static class WeatherTime extends Module {
        WeatherTime(String n, String c, String[] p) { super(n, c, p); implemented = true; }
        public void onTick() {
            if (mc.field_71441_e == null) return;
            if (b("Constant Time")) mc.field_71441_e.func_72877_b((long) n("Time of Day"));
            switch (mode("Weather Lock")) {
                case 1: mc.field_71441_e.func_72894_k(0f); mc.field_71441_e.func_147442_i(0f); break;
                case 2: mc.field_71441_e.func_72894_k(1f); mc.field_71441_e.func_147442_i(0f); break;
                case 3: mc.field_71441_e.func_72894_k(1f); mc.field_71441_e.func_147442_i(1f); break;
            }
        }
        public void onRender(ScaledResolution sr, float pt) {
            if (b("Sky Tint Overlay")) Draw.rect(0, 0, sr.func_78326_a(), sr.func_78328_b(), Draw.mulA(c("Sky Tint Color"), (float) n("Sky Tint Opacity")));
        }
    }

    // ---------------- Server specific ----------------
    public static class HypixelMods extends Module {
        int delay = -1;
        HypixelMods(String n, String c, String[] p) { super(n, c, p); implemented = true; }
        static boolean onHypixel() { ServerData sd = mc.func_147104_D(); return sd != null && sd.field_78845_b != null && sd.field_78845_b.toLowerCase().contains("hypixel"); }
        public void onChat(ClientChatReceivedEvent e) {
            if (!b("Auto GG") || e.type == 2 || !onHypixel()) return; String m = e.message.func_150260_c();
            if (m.contains("1st Killer -") || m.contains("Winner -") || m.contains("Winners -") || m.contains("WINNER!") || m.contains("1st Place")) delay = 20;
        }
        public void onTick() { if (delay > 0 && --delay == 0 && mc.field_71439_g != null) mc.field_71439_g.func_71165_d("/achat gg"); }
    }
}
