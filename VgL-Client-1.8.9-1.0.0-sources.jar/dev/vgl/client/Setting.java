package dev.vgl.client;

public class Setting {
    public enum T { BOOL, NUM, MODE, COLOR }
    public final String name; public final T type;
    public boolean b; public double n, min, max; public String[] modes; public int idx; public int color = 0xFFFFFFFF;
    public Setting(String name, T type) { this.name = name; this.type = type; }
    public String modeName() { return modes[idx]; }

    /** "Name" = bool(on), "-Name" = bool(off), "~Name:min:max:def", "@Name:A|B|C", "#Name" or "#Name=RRGGBB" */
    public static Setting parse(String spec) {
        char c = spec.charAt(0);
        if (c == '~') {
            String[] p = spec.substring(1).split(":");
            Setting s = new Setting(p[0], T.NUM);
            s.min = Double.parseDouble(p[1]); s.max = Double.parseDouble(p[2]); s.n = Double.parseDouble(p[3]);
            return s;
        }
        if (c == '@') {
            int i = spec.indexOf(':');
            Setting s = new Setting(spec.substring(1, i), T.MODE);
            s.modes = spec.substring(i + 1).split("\\|");
            return s;
        }
        if (c == '#') {
            String n = spec.substring(1); int rgb = 0xFFFFFF; int e = n.indexOf('=');
            if (e > 0) { rgb = Integer.parseInt(n.substring(e + 1), 16); n = n.substring(0, e); }
            Setting s = new Setting(n, T.COLOR); s.color = 0xFF000000 | rgb; return s;
        }
        Setting s;
        if (c == '-') { s = new Setting(spec.substring(1), T.BOOL); s.b = false; }
        else { s = new Setting(spec, T.BOOL); s.b = true; }
        return s;
    }
}
