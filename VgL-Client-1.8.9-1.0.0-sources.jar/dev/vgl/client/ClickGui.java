package dev.vgl.client;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.util.ChatAllowedCharacters;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

/** Liquid Glass mod menu. Opens/closes with RIGHT SHIFT (or ESC). */
public class ClickGui extends GuiScreen {
    static final int W = 620, H = 380, ACC = 0xFF5AC8FF;
    static final int[] PAL = {0xFFFFFF, 0xFF5555, 0xFFAA00, 0xFFFF55, 0x55FF55, 0x55FFFF, 0x5555FF, 0xAA55FF, 0xFF55FF, 0x000000, 0xAAAAAA, 0x5AC8FF};

    interface Drag { void to(float mx); }
    static class Hit {
        float x, y, w, h, cy, ch; Runnable click; Drag drag;
        Hit(float x, float y, float w, float h, float cy, float ch, Runnable c, Drag d) { this.x = x; this.y = y; this.w = w; this.h = h; this.cy = cy; this.ch = ch; click = c; drag = d; }
        boolean in(float mx, float my) { return mx >= x && mx <= x + w && my >= y && my <= y + h && my >= cy && my <= cy + ch; }
    }
    final List<Hit> hits = new ArrayList<Hit>();
    Hit dragging;
    int cat = 0; Module sel; String search = ""; boolean closing; float mS, mT, sS, sT, prog;
    float cx, cy, off, sc;

    @Override public void func_73866_w_() {
        if (field_146297_k.field_71441_e != null && OpenGlHelper.field_148824_g) { try { field_146297_k.field_71460_t.func_175069_a(new ResourceLocation("shaders/post/blur.json")); } catch (Exception e) { } }
    }
    @Override public void func_146281_b() { if (field_146297_k.field_71460_t.func_147702_a()) field_146297_k.field_71460_t.func_181022_b(); Config.save(); }
    @Override public boolean func_73868_f() { return false; }

    void clip(float x, float y, float w, float h) {
        float X = cx + sc * (x - cx), Y = cy + off + sc * (y - cy); int f = new ScaledResolution(field_146297_k).func_78325_e();
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor((int) (X * f), (int) (field_146297_k.field_71440_d - (Y + h * sc) * f), Math.max(0, (int) (w * sc * f)), Math.max(0, (int) (h * sc * f)));
    }
    void unclip() { GL11.glDisable(GL11.GL_SCISSOR_TEST); }
    static boolean over(float mx, float my, float x, float y, float w, float h) { return mx >= x && mx <= x + w && my >= y && my <= y + h; }
    void hit(float x, float y, float w, float h, Runnable c) { hits.add(new Hit(x, y, w, h, -1e9f, 2e9f, c, null)); }

    void pill(Object key, float x, float y, float w, float h, boolean on, float a) {
        float t = Anim.get(key, on ? 1 : 0, 16f, on ? 1 : 0);
        int bg = Draw.lerp(Draw.argb(.18f * a, 255, 255, 255), Draw.mulA(ACC, .75f * a), t);
        Draw.rrect(x, y, w, h, h / 2, bg, Draw.mulA(bg, .75f));
        Draw.stroke(x, y, w, h, h / 2, Draw.argb(.6f * a, 255, 255, 255), Draw.argb(.15f * a, 255, 255, 255), 1f);
        float k = h - 4; Draw.rrect(x + 2 + (w - k - 4) * t, y + 2, k, k, k / 2, Draw.argb(.98f * a, 255, 255, 255), Draw.argb(.8f * a, 220, 235, 255));
    }

    @Override public void func_73863_a(int mx, int my, float pt) {
        Anim.tick(); hits.clear();
        prog = Anim.get("open", closing ? 0 : 1, 12f);
        if (closing && prog < 0.02f) { field_146297_k.func_147108_a(null); return; }
        float a = prog, e = 1 - (1 - prog) * (1 - prog) * (1 - prog);
        sc = 0.9f + 0.1f * e; cx = field_146294_l / 2f; cy = field_146295_m / 2f; off = (1 - e) * 18;
        float x0 = (field_146294_l - W) / 2f, y0 = (field_146295_m - H) / 2f;

        func_73733_a(0, 0, field_146294_l, field_146295_m, Draw.argb(.5f * a, 22, 12, 60), Draw.argb(.5f * a, 4, 34, 64));
        double t = System.currentTimeMillis() / 1000.0;
        Draw.orb((float) (cx - 170 + Math.sin(t * .5) * 70), (float) (cy - 60 + Math.cos(t * .4) * 50), 190, 0x7A5CFF, .55f * a);
        Draw.orb((float) (cx + 190 + Math.cos(t * .45) * 60), (float) (cy + 70 + Math.sin(t * .6) * 50), 210, 0x2FD4FF, .5f * a);
        Draw.orb((float) (cx + Math.sin(t * .3) * 120), (float) (cy + 140 + Math.cos(t * .35) * 30), 170, 0xFF5CAA, .35f * a);

        GlStateManager.func_179094_E(); GlStateManager.func_179109_b(cx, cy + off, 0); GlStateManager.func_179152_a(sc, sc, 1); GlStateManager.func_179109_b(-cx, -cy, 0);
        Draw.glass(x0, y0, W, H, 20, a);

        // ---- sidebar ----
        Draw.rrect(x0 + 8, y0 + 8, 112, H - 16, 14, Draw.argb(.10f * a, 255, 255, 255), Draw.argb(.03f * a, 255, 255, 255));
        GlStateManager.func_179094_E(); GlStateManager.func_179109_b(x0 + 20, y0 + 18, 0); GlStateManager.func_179152_a(2f, 2f, 1); Draw.text("VgL", 0, 0, Draw.mulA(ACC, a), true); GlStateManager.func_179121_F();
        Draw.text("CLIENT  1.8.9", x0 + 21, y0 + 38, Draw.argb(.6f * a, 255, 255, 255), false);
        for (int i = 0; i < Catalog.CATS.length; i++) {
            final int ci = i; float ry = y0 + 70 + i * 34; boolean hov = over(mx, my, x0 + 14, ry, 100, 28);
            float h = Anim.get("cat" + i, cat == i ? 1 : hov ? .45f : 0, 16f, cat == i ? 1 : 0);
            if (h > .01f) { Draw.rrect(x0 + 14, ry, 100, 28, 10, Draw.argb(.26f * h * a, 130, 195, 255), Draw.argb(.10f * h * a, 130, 195, 255)); Draw.stroke(x0 + 14, ry, 100, 28, 10, Draw.argb(.5f * h * a, 255, 255, 255), Draw.argb(.1f * h * a, 255, 255, 255), 1f); }
            Draw.text(Catalog.CATS[i], x0 + 22 + h * 3, ry + 10, Draw.argb(a * (.65f + .35f * h), 255, 255, 255), false);
            hit(x0 + 14, ry, 100, 28, new Runnable() { public void run() { cat = ci; sel = null; mT = mS = sT = sS = 0; } });
        }
        int en = 0; for (Module m : Catalog.ALL) if (m.enabled) en++;
        Draw.text(en + "/" + Catalog.ALL.size() + " enabled", x0 + 22, y0 + H - 24, Draw.argb(.5f * a, 255, 255, 255), false);

        // ---- module list ----
        float lx = x0 + 130, ly = y0 + 44, lw = 210, lh = H - 56;
        Draw.rrect(lx, y0 + 12, lw, 24, 12, Draw.argb(.12f * a, 255, 255, 255), Draw.argb(.05f * a, 255, 255, 255));
        Draw.stroke(lx, y0 + 12, lw, 24, 12, Draw.argb(.4f * a, 255, 255, 255), Draw.argb(.1f * a, 255, 255, 255), 1f);
        boolean caret = (System.currentTimeMillis() / 500) % 2 == 0;
        Draw.text(search.isEmpty() ? "Type to search..." : search + (caret ? "|" : ""), lx + 12, y0 + 20, Draw.argb((search.isEmpty() ? .45f : .95f) * a, 255, 255, 255), false);
        List<Module> mods = new ArrayList<Module>();
        for (Module m : Catalog.byCat(cat)) if (search.isEmpty() || m.name.toLowerCase().contains(search.toLowerCase())) mods.add(m);
        if (!search.isEmpty()) { mods.clear(); for (Module m : Catalog.ALL) if (m.name.toLowerCase().contains(search.toLowerCase())) mods.add(m); }
        float maxM = Math.max(0, mods.size() * 30 - lh); mT = Math.max(0, Math.min(maxM, mT)); mS += (mT - mS) * Math.min(1, Anim.dt * 14);
        clip(lx - 4, ly, lw + 8, lh);
        for (int i = 0; i < mods.size(); i++) {
            final Module m = mods.get(i); float ry = ly + i * 30 - mS; if (ry < ly - 28 || ry > ly + lh) continue;
            boolean hov = over(mx, my, lx, ry, lw, 26) && my >= ly && my <= ly + lh; boolean s = m == sel;
            float h = Anim.get(m.name + "row", s ? 1 : hov ? .5f : 0, 16f);
            Draw.rrect(lx, ry, lw, 26, 10, Draw.argb((.10f + .16f * h) * a, 255, 255, 255), Draw.argb((.04f + .06f * h) * a, 255, 255, 255));
            Draw.stroke(lx, ry, lw, 26, 10, Draw.argb((.3f + .3f * h) * a, 255, 255, 255), Draw.argb(.08f * a, 255, 255, 255), 1f);
            Draw.text(m.name.length() > 24 ? m.name.substring(0, 23) + "." : m.name, lx + 10 + h * 2, ry + (m.implemented ? 9 : 5), Draw.argb(a * .95f, 255, 255, 255), false);
            if (!m.implemented) Draw.text("preview", lx + 10 + h * 2, ry + 15, Draw.argb(a * .4f, 255, 255, 255), false);
            pill(m.name + "en", lx + lw - 42, ry + 5, 32, 16, m.enabled, a);
            hits.add(new Hit(lx, ry, lw - 48, 26, ly, lh, new Runnable() { public void run() { sel = m; sT = sS = 0; } }, null));
            hits.add(new Hit(lx + lw - 46, ry, 42, 26, ly, lh, new Runnable() { public void run() { m.toggle(); Config.save(); } }, null));
        }
        unclip();
        if (mods.isEmpty()) Draw.text("No mods found", lx + 10, ly + 8, Draw.argb(.5f * a, 255, 255, 255), false);

        // ---- settings panel ----
        float sx = x0 + 352, sy = y0 + 12, sw = W - 352 - 14, shh = H - 24;
        Draw.rrect(sx - 6, sy, sw + 12, shh, 14, Draw.argb(.08f * a, 255, 255, 255), Draw.argb(.03f * a, 255, 255, 255));
        if (sel == null) Draw.ctext("Select a mod to configure", sx + sw / 2, sy + shh / 2 - 4, Draw.argb(.5f * a, 255, 255, 255), false);
        else {
            Draw.text(sel.name, sx + 6, sy + 10, Draw.argb(a, 255, 255, 255), true);
            Draw.text(sel.implemented ? "Active mod" : "Preview - saved, not wired yet", sx + 6, sy + 22, Draw.argb(.5f * a, 255, 255, 255), false);
            pill(sel.name + "big", sx + sw - 38, sy + 9, 34, 17, sel.enabled, a);
            final Module sm = sel; hit(sx + sw - 40, sy + 8, 38, 20, new Runnable() { public void run() { sm.toggle(); Config.save(); } });
            float py = sy + 38, ph = shh - 44; float total = 0;
            for (Setting st : sel.settings.values()) total += st.type == Setting.T.NUM ? 34 : st.type == Setting.T.COLOR ? 44 : 24;
            sT = Math.max(0, Math.min(Math.max(0, total - ph), sT)); sS += (sT - sS) * Math.min(1, Anim.dt * 14);
            clip(sx - 4, py, sw + 8, ph);
            float y = py - sS;
            for (final Setting st : sel.settings.values()) {
                float rh = st.type == Setting.T.NUM ? 34 : st.type == Setting.T.COLOR ? 44 : 24;
                if (y > py - rh && y < py + ph) {
                    int tc = Draw.argb(.92f * a, 255, 255, 255); final float yy = y;
                    switch (st.type) {
                        case BOOL:
                            Draw.text(st.name, sx + 6, y + 8, tc, false); pill(sel.name + st.name, sx + sw - 38, y + 4, 30, 15, st.b, a);
                            hits.add(new Hit(sx, y, sw, rh, py, ph, new Runnable() { public void run() { st.b = !st.b; } }, null)); break;
                        case NUM: {
                            boolean wide = st.max - st.min >= 20; String v = wide ? "" + (long) Math.round(st.n) : String.format("%.2f", st.n);
                            Draw.text(st.name, sx + 6, y + 4, tc, false); Draw.text(v, sx + sw - 8 - Draw.w(v), y + 4, Draw.mulA(ACC, a), false);
                            final float tx = sx + 6, tw = sw - 12; float fr = (float) ((st.n - st.min) / (st.max - st.min));
                            float fa = Anim.get(sel.name + st.name + "s", fr, 20f, fr);
                            Draw.rrect(tx, y + 21, tw, 4, 2, Draw.argb(.2f * a, 255, 255, 255), Draw.argb(.1f * a, 255, 255, 255));
                            Draw.rrect(tx, y + 21, Math.max(4, tw * fa), 4, 2, Draw.mulA(ACC, .9f * a), Draw.mulA(ACC, .6f * a));
                            Draw.rrect(tx + tw * fa - 5, y + 18, 10, 10, 5, Draw.argb(a, 255, 255, 255), Draw.argb(.8f * a, 215, 235, 255));
                            final boolean w2 = wide;
                            hits.add(new Hit(sx, y + 14, sw, 18, py, ph, null, new Drag() { public void to(float m) {
                                float q = Math.max(0, Math.min(1, (m - tx) / tw)); double d = st.min + (st.max - st.min) * q;
                                st.n = w2 ? Math.round(d) : Math.round(d * 100) / 100.0; } })); break; }
                        case MODE: {
                            Draw.text(st.name, sx + 6, y + 8, tc, false); String v = st.modeName(); float cw = Draw.w(v) + 16;
                            Draw.rrect(sx + sw - cw - 4, y + 2, cw, 18, 9, Draw.argb(.2f * a, 255, 255, 255), Draw.argb(.08f * a, 255, 255, 255));
                            Draw.stroke(sx + sw - cw - 4, y + 2, cw, 18, 9, Draw.argb(.5f * a, 255, 255, 255), Draw.argb(.1f * a, 255, 255, 255), 1f);
                            Draw.ctext(v, sx + sw - cw / 2 - 4, y + 7, Draw.mulA(ACC, a), false);
                            hits.add(new Hit(sx, y, sw, rh, py, ph, new Runnable() { public void run() { st.idx = (st.idx + 1) % st.modes.length; } }, null)); break; }
                        default: {
                            Draw.text(st.name, sx + 6, y + 4, tc, false);
                            Draw.rrect(sx + sw - 30, y + 2, 22, 11, 5, Draw.mulA(st.color, a), Draw.mulA(st.color, a));
                            Draw.stroke(sx + sw - 30, y + 2, 22, 11, 5, Draw.argb(.8f * a, 255, 255, 255), Draw.argb(.3f * a, 255, 255, 255), 1f);
                            for (int i = 0; i < PAL.length; i++) {
                                final int pc = 0xFF000000 | PAL[i]; float bx = sx + 6 + i * 20.5f; boolean sel2 = st.color == pc; float hv = Anim.get(sel.name + st.name + i, sel2 ? 1 : 0, 18f);
                                Draw.rrect(bx - hv, y + 21 - hv, 15 + 2 * hv, 15 + 2 * hv, 7, Draw.mulA(pc, a), Draw.mulA(pc, a));
                                Draw.stroke(bx - hv, y + 21 - hv, 15 + 2 * hv, 15 + 2 * hv, 7, Draw.argb((.35f + .6f * hv) * a, 255, 255, 255), Draw.argb(.1f * a, 255, 255, 255), 1f + hv);
                                hits.add(new Hit(bx, y + 21, 15, 15, py, ph, new Runnable() { public void run() { st.color = pc; } }, null));
                            } }
                    }
                }
                y += rh;
            }
            unclip();
        }
        GlStateManager.func_179121_F();
        Draw.text("RIGHT SHIFT to close", 6, field_146295_m - 12, Draw.argb(.35f * a, 255, 255, 255), false);
    }

    @Override protected void func_73864_a(int mx, int my, int btn) throws IOException {
        if (btn != 0 || prog < .9f || closing) return;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.in(mx, my)) { if (h.click != null) h.click.run(); if (h.drag != null) { dragging = h; h.drag.to(mx); } return; }
        }
    }
    @Override protected void func_146273_a(int mx, int my, int btn, long t) { if (dragging != null && dragging.drag != null) dragging.drag.to(mx); }
    @Override protected void func_146286_b(int mx, int my, int state) { if (dragging != null) Config.save(); dragging = null; }

    @Override public void func_146274_d() throws IOException {
        super.func_146274_d();
        int d = Mouse.getEventDWheel();
        if (d != 0) { float mx = Mouse.getEventX() * field_146294_l / (float) field_146297_k.field_71443_c, x0 = (field_146294_l - W) / 2f; if (mx < x0 + 346) mT -= Math.signum(d) * 45; else sT -= Math.signum(d) * 45; }
    }
    @Override protected void func_73869_a(char c, int key) throws IOException {
        if (key == Keyboard.KEY_RSHIFT || key == Keyboard.KEY_ESCAPE) { closing = true; return; }
        if (key == Keyboard.KEY_BACK) { if (!search.isEmpty()) search = search.substring(0, search.length() - 1); mT = 0; }
        else if (ChatAllowedCharacters.func_71566_a(c)) { search += c; mT = 0; }
    }
}
