package dev.vgl.client;

import java.util.Arrays;
import java.util.List;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;

/** Base for on-screen widgets: adds Pos X/Y sliders and renders lines() on a glass panel. */
public abstract class HudModule extends Module {
    static int count = 0;
    public HudModule(String n, String c, String[] p) { super(n, c, concat(p, count)); count++; implemented = true; }
    static String[] concat(String[] p, int i) {
        String[] r = Arrays.copyOf(p, p.length + 2);
        r[p.length] = "~Pos X %:0:100:" + (1 + (i / 6) * 17);
        r[p.length + 1] = "~Pos Y %:0:100:" + (3 + (i % 6) * 12);
        return r;
    }
    protected List<String> lines() { return null; }
    protected int color() { return textColor(); }
    protected int textColor() { Setting s = settings.get("Text Color"); if (s == null) s = settings.get("Color"); return s != null ? s.color : 0xFFFFFFFF; }
    protected boolean bg() { Setting s = settings.get("Show Background"); return s == null || s.b; }
    protected float scale() { Setting s = settings.get("Font Size"); if (s == null) s = settings.get("Font Scale"); return s != null ? (float) s.n : 1f; }
    protected boolean shadow() { Setting s = settings.get("Text Shadow"); if (s == null) s = settings.get("Shadow Effect"); return s == null || s.b; }
    protected float bgAlpha() { Setting s = settings.get("Background Opacity"); if (s == null) s = settings.get("Background Transparency"); return s != null ? (float) s.n : 0.5f; }
    protected float px(ScaledResolution sr) { return sr.func_78326_a() * (float) n("Pos X %") / 100f; }
    protected float py(ScaledResolution sr) { return sr.func_78328_b() * (float) n("Pos Y %") / 100f; }

    @Override public void onRender(ScaledResolution sr, float pt) {
        List<String> l = lines(); if (l == null || l.isEmpty()) return;
        int w = 0; for (String s : l) w = Math.max(w, Draw.w(s));
        float pw = w + 10, ph = l.size() * 10 + 6, sc = scale();
        GlStateManager.func_179094_E(); GlStateManager.func_179109_b(px(sr), py(sr), 0); GlStateManager.func_179152_a(sc, sc, 1);
        if (bg()) Draw.glass(0, 0, pw, ph, 6, Math.min(1f, bgAlpha() * 1.6f));
        for (int i = 0; i < l.size(); i++) Draw.text(l.get(i), 5, 4 + i * 10, color(), shadow());
        GlStateManager.func_179121_F();
    }
}
