package dev.vgl.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

/** Rounded-rect + "Liquid Glass" primitives (vertical gradients, specular highlight, soft shadow). */
public class Draw {
    static final Minecraft mc = Minecraft.func_71410_x();

    public static int argb(float a, int r, int g, int b) {
        int A = (int) (Math.max(0, Math.min(1, a)) * 255); return (A << 24) | (r << 16) | (g << 8) | b;
    }
    public static int mulA(int c, float a) {
        int A = (int) (((c >>> 24) & 255) * Math.max(0, Math.min(1, a))); return (A << 24) | (c & 0xFFFFFF);
    }
    public static int lerp(int a, int b, float t) {
        t = Math.max(0, Math.min(1, t)); int r = 0;
        for (int s = 24; s >= 0; s -= 8) { int x = (a >>> s) & 255, y = (b >>> s) & 255; r |= ((int) (x + (y - x) * t) & 255) << s; }
        return r;
    }
    static void col(int c) { GL11.glColor4f(((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f, ((c >>> 24) & 255) / 255f); }
    static void begin() { GlStateManager.func_179147_l(); GlStateManager.func_179090_x(); GlStateManager.func_179118_c(); GlStateManager.func_179120_a(770, 771, 1, 0); }
    static void end() { GlStateManager.func_179098_w(); GlStateManager.func_179141_d(); GlStateManager.func_179147_l(); GlStateManager.func_179131_c(1, 1, 1, 1); }

    static float[][] outline(float x, float y, float w, float h, float r) {
        r = Math.max(0.5f, Math.min(r, Math.min(w, h) / 2)); int seg = 8; float[][] p = new float[4 * (seg + 1)][]; int k = 0;
        float[] cx = {x + w - r, x + w - r, x + r, x + r}, cy = {y + r, y + h - r, y + h - r, y + r}, a0 = {270, 0, 90, 180};
        for (int i = 0; i < 4; i++) for (int j = 0; j <= seg; j++) {
            double a = Math.toRadians(a0[i] + 90.0 * j / seg);
            p[k++] = new float[]{(float) (cx[i] + r * Math.cos(a)), (float) (cy[i] + r * Math.sin(a))};
        }
        return p;
    }
    public static void rrect(float x, float y, float w, float h, float r, int top, int bot) {
        begin(); float[][] p = outline(x, y, w, h, r);
        GL11.glBegin(GL11.GL_TRIANGLE_FAN); col(lerp(top, bot, .5f)); GL11.glVertex2f(x + w / 2, y + h / 2);
        for (int i = 0; i <= p.length; i++) { float[] q = p[i % p.length]; col(lerp(top, bot, (q[1] - y) / h)); GL11.glVertex2f(q[0], q[1]); }
        GL11.glEnd(); end();
    }
    public static void stroke(float x, float y, float w, float h, float r, int top, int bot, float lw) {
        begin(); GL11.glEnable(GL11.GL_LINE_SMOOTH); GL11.glLineWidth(lw); float[][] p = outline(x, y, w, h, r);
        GL11.glBegin(GL11.GL_LINE_LOOP);
        for (float[] q : p) { col(lerp(top, bot, (q[1] - y) / h)); GL11.glVertex2f(q[0], q[1]); }
        GL11.glEnd(); GL11.glDisable(GL11.GL_LINE_SMOOTH); end();
    }
    /** The signature look: soft shadow, frosted vertical-gradient body, bright rim, top specular band. */
    public static void glass(float x, float y, float w, float h, float r, float a) {
        rrect(x - 1, y + 2, w + 2, h + 2, r + 1, argb(.16f * a, 0, 0, 0), argb(.28f * a, 0, 0, 0));
        rrect(x, y, w, h, r, argb(.22f * a, 255, 255, 255), argb(.07f * a, 190, 220, 255));
        stroke(x, y, w, h, r, argb(.75f * a, 255, 255, 255), argb(.14f * a, 255, 255, 255), 1.2f);
        float bh = Math.min(h * .4f, 16); if (h > 10) rrect(x + 2, y + 1.5f, w - 4, bh, Math.max(1, r - 2), argb(.17f * a, 255, 255, 255), argb(0, 255, 255, 255));
    }
    public static void rect(float x, float y, float w, float h, int c) {
        begin(); col(c); GL11.glBegin(GL11.GL_QUADS);
        GL11.glVertex2f(x, y + h); GL11.glVertex2f(x + w, y + h); GL11.glVertex2f(x + w, y); GL11.glVertex2f(x, y);
        GL11.glEnd(); end();
    }
    public static void line(float x1, float y1, float x2, float y2, float lw, int c) {
        begin(); GL11.glEnable(GL11.GL_LINE_SMOOTH); GL11.glLineWidth(lw); col(c);
        GL11.glBegin(GL11.GL_LINES); GL11.glVertex2f(x1, y1); GL11.glVertex2f(x2, y2); GL11.glEnd(); GL11.glDisable(GL11.GL_LINE_SMOOTH); end();
    }
    public static void ring(float cx, float cy, float r, int c, float lw) {
        begin(); GL11.glEnable(GL11.GL_LINE_SMOOTH); GL11.glLineWidth(lw); col(c); GL11.glBegin(GL11.GL_LINE_LOOP);
        for (int i = 0; i < 36; i++) { double t = i * Math.PI * 2 / 36; GL11.glVertex2f((float) (cx + r * Math.cos(t)), (float) (cy + r * Math.sin(t))); }
        GL11.glEnd(); GL11.glDisable(GL11.GL_LINE_SMOOTH); end();
    }
    /** Soft radial glow, used for the drifting colour blobs behind the menu. */
    public static void orb(float cx, float cy, float r, int rgb, float a) {
        begin(); GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        col(argb(a, (rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255)); GL11.glVertex2f(cx, cy);
        col(argb(0, (rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255));
        for (int i = 0; i <= 40; i++) { double t = i * Math.PI * 2 / 40; GL11.glVertex2f((float) (cx + r * Math.cos(t)), (float) (cy + r * Math.sin(t))); }
        GL11.glEnd(); end();
    }
    public static void text(String s, float x, float y, int c, boolean sh) {
        if (s == null || ((c >>> 24) & 255) < 6) return; // FontRenderer treats tiny alpha as opaque
        mc.field_71466_p.func_175065_a(s, x, y, c, sh); GlStateManager.func_179131_c(1, 1, 1, 1);
    }
    public static void ctext(String s, float cx, float y, int c, boolean sh) { text(s, cx - mc.field_71466_p.func_78256_a(s) / 2f, y, c, sh); }
    public static int w(String s) { return mc.field_71466_p.func_78256_a(s); }
}
