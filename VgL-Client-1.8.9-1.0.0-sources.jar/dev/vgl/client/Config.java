package dev.vgl.client;

import com.google.gson.*;
import java.io.*;
import net.minecraft.client.Minecraft;

public class Config {
    static File file() { File f = new File(Minecraft.func_71410_x().field_71412_D, "config/vgl-client.json"); f.getParentFile().mkdirs(); return f; }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Module m : Catalog.ALL) {
                JsonObject o = new JsonObject(); o.addProperty("enabled", m.enabled);
                for (Setting s : m.settings.values()) {
                    switch (s.type) {
                        case BOOL: o.addProperty(s.name, s.b); break;
                        case NUM: o.addProperty(s.name, s.n); break;
                        case MODE: o.addProperty(s.name, s.idx); break;
                        case COLOR: o.addProperty(s.name, s.color); break;
                    }
                }
                root.add(m.name, o);
            }
            Writer w = new FileWriter(file()); new GsonBuilder().setPrettyPrinting().create().toJson(root, w); w.close();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public static void load() {
        File f = file(); if (!f.exists()) return;
        try {
            Reader r = new FileReader(f); JsonObject root = new JsonParser().parse(r).getAsJsonObject(); r.close();
            for (Module m : Catalog.ALL) {
                if (!root.has(m.name)) continue; JsonObject o = root.getAsJsonObject(m.name);
                for (Setting s : m.settings.values()) {
                    if (!o.has(s.name)) continue; JsonElement e = o.get(s.name);
                    switch (s.type) {
                        case BOOL: s.b = e.getAsBoolean(); break;
                        case NUM: s.n = e.getAsDouble(); break;
                        case MODE: s.idx = Math.max(0, Math.min(s.modes.length - 1, e.getAsInt())); break;
                        case COLOR: s.color = e.getAsInt(); break;
                    }
                }
                if (o.has("enabled")) m.setEnabled(o.get("enabled").getAsBoolean());
            }
        } catch (Exception e) { e.printStackTrace(); }
    }
}
