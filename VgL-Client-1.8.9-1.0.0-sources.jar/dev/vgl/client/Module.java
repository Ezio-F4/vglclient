package dev.vgl.client;

import java.util.LinkedHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.client.event.*;
import net.minecraftforge.event.entity.player.AttackEntityEvent;

public class Module {
    protected static final Minecraft mc = Minecraft.func_71410_x();
    public final String name, category;
    public boolean enabled;
    public boolean implemented = false; // false = settings exist, behaviour not wired yet
    public final LinkedHashMap<String, Setting> settings = new LinkedHashMap<String, Setting>();

    public Module(String name, String category, String... specs) {
        this.name = name; this.category = category;
        for (String s : specs) { Setting st = Setting.parse(s); settings.put(st.name, st); }
    }
    public void toggle() { setEnabled(!enabled); }
    public void setEnabled(boolean v) {
        if (v == enabled) return;
        enabled = v;
        try { if (v) onEnable(); else onDisable(); } catch (Throwable t) { t.printStackTrace(); }
    }
    protected Setting find(String n) { return settings.get(n); }
    protected boolean b(String n) { Setting s = settings.get(n); return s != null && s.b; }
    protected double n(String n) { Setting s = settings.get(n); return s == null ? 0 : s.n; }
    protected int mode(String n) { Setting s = settings.get(n); return s == null ? 0 : s.idx; }
    protected int c(String n) { Setting s = settings.get(n); return s == null ? 0xFFFFFFFF : s.color; }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    public void onRender(ScaledResolution sr, float pt) {}
    public void onOverlayPre(RenderGameOverlayEvent.Pre e) {}
    public void onFov(FOVUpdateEvent e) {}
    public void onMouse(MouseEvent e) {}
    public void onChat(ClientChatReceivedEvent e) {}
    public void onAttack(AttackEntityEvent e) {}
}
