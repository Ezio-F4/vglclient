package dev.vgl.client;

import java.util.ArrayList;
import java.util.List;

public class Catalog {
    public static final List<Module> ALL = new ArrayList<Module>();
    public static final String[] CATS = {"PvP & Combat", "Performance & Utility", "Interface & QoL", "Server & Game Mode"};

    public static List<Module> byCat(int c) { List<Module> l = new ArrayList<Module>(); for (Module m : ALL) if (m.category.equals(CATS[c])) l.add(m); return l; }

    static void a(int cat, String n, String... p) {
        String c = CATS[cat]; Module m;
        if (n.equals("Clicks Per Second (CPS)")) m = new Impl.Cps(n, c, p);
        else if (n.equals("Crosshair")) m = new Impl.Crosshair(n, c, p);
        else if (n.equals("Armor Status")) m = new Impl.ArmorStatus(n, c, p);
        else if (n.equals("Keystrokes")) m = new Impl.Keystrokes(n, c, p);
        else if (n.equals("Reach Display")) m = new Impl.ReachDisplay(n, c, p);
        else if (n.equals("Toggle Sneak & Toggle Sprint")) m = new Impl.ToggleSprintSneak(n, c, p);
        else if (n.equals("Potion Effects")) m = new Impl.Potions(n, c, p);
        else if (n.equals("Hitboxes")) m = new Impl.Hitboxes(n, c, p);
        else if (n.equals("Frames Per Second (FPS) Display")) m = new Impl.Fps(n, c, p);
        else if (n.equals("Coordinates")) m = new Impl.Coords(n, c, p);
        else if (n.equals("Memory Usage")) m = new Impl.Memory(n, c, p);
        else if (n.equals("Angle Mod")) m = new Impl.AngleMod(n, c, p);
        else if (n.equals("Direction HUD")) m = new Impl.DirectionHud(n, c, p);
        else if (n.equals("Lighting Mod / Fullbright")) m = new Impl.Fullbright(n, c, p);
        else if (n.equals("FOV Changer")) m = new Impl.Fov(n, c, p);
        else if (n.equals("Zoom")) m = new Impl.Zoom(n, c, p);
        else if (n.equals("Menu Blur")) m = new Impl.MenuBlur(n, c, p);
        else if (n.equals("Boss Bar")) m = new Impl.BossBar(n, c, p);
        else if (n.equals("Weather & Time Changer")) m = new Impl.WeatherTime(n, c, p);
        else if (n.equals("Hypixel Mods")) m = new Impl.HypixelMods(n, c, p);
        else m = new Module(n, c, p);
        ALL.add(m);
        if (n.equals("Frames Per Second (FPS) Display") || n.equals("Clicks Per Second (CPS)") || n.equals("Coordinates")) m.enabled = true;
    }

    public static void init() {
        // ---- PvP & Combat ----
        a(0, "1.7 Visuals", "Block Hitting", "Sword Animations", "Bow Animations", "Armor Red Tint", "@Sneaking Style:1.7|1.8", "Eating Animation", "@Rod Position:1.7|1.8", "Critical Hit Particles");
        a(0, "Armor Status", "Toggle Armor", "Toggle Held Item", "Display Durability", "-Display Percentage", "~Damage Threshold Warning:0:100:20", "@Position Mode:Static|Dynamic", "#Text Color", "~Icon Scaling:0.5:2:1");
        a(0, "Clicks Per Second (CPS)", "Left Click Display", "Right Click Display", "Show Background", "Text Shadow", "#Text Color", "@Border Style:None|Thin|Glow", "@Layout:Horizontal|Vertical");
        a(0, "Cooldowns", "Ender Pearl Timer", "Attack Cooldown Indicator", "Chorus Fruit Timer", "-Custom Server Cooldown Sync", "~Icon Size:8:32:16", "~Font Scale:0.5:2:1", "Alert Notification");
        a(0, "Crosshair", "-Dynamic Crosshair", "@Crosshair Type:Cross|Dot|Circle|Arrow", "~Width:1:20:6", "~Height:1:20:6", "~Gap Size:0:10:2", "~Thickness:1:5:1", "#Color", "#Outline Color=000000", "Hide while Spectating");
        a(0, "Damage Tint", "~Health Threshold Trigger:1:20:6", "~Vignette Intensity:0:1:0.5", "Heartbeat Sound Sync", "~Red Flash Speed:0.5:5:1", "-Mute Sound");
        a(0, "Hit Color", "#Custom Damage Flash Color=FF0000", "~Flash Opacity:0:1:0.5", "~Flash Duration:100:2000:500", "Apply to Self", "Apply to Mobs");
        a(0, "Hitboxes", "Show Hitbox", "Show Eye Level", "Show Vector Line", "#Line Color=FFFFFF", "~Line Thickness:1:5:1", "Projectile Hitboxes", "@Entity Filter:All|Passive|Hostile");
        a(0, "Keystrokes", "Display WASD", "Mouse Button Display", "Spacebar Display", "CPS Overlay", "#Key Click Color=FFFFFF", "#Default Key Color=000000", "#Text Color", "~Fade Delay:30:1000:150");
        a(0, "Potion Effects", "@Layout:Vertical|Horizontal", "-Hide Icon", "-Hide Name", "-Compact Mode", "Countdown Clock", "#Text Color", "~Warning Flash Duration:0:30:10", "@Sorting Order:Duration|Name|Amplifier");
        a(0, "Reach Display", "Display Hit Distance", "~Text Decimal Length:0:3:2", "~Timeout Reset:1:30:5", "@Text Format:%s blocks|[%s]|%s m", "#Color", "Background Shadow");
        a(0, "Toggle Sneak & Toggle Sprint", "Toggle Sprint", "Toggle Sneak", "HUD Indicator Status", "-Custom Text", "-Double Tap Sprint Alternative", "-Vanilla Hold Mode Bypass", "Inventory Sneaking Fix");
        // ---- Performance & Utility ----
        a(1, "2D Items", "Enable Flat Drops", "Apply to Ground Items", "-Exclude Specific Items", "~Scale Factor:0.5:3:1", "~Rotation Override:0:360:0");
        a(1, "Angle Mod", "Show Pitch", "Show Yaw", "-Grid Guide", "Round to Nearest Int", "#Text Color", "-Snap Lock Angles");
        a(1, "Coordinates", "@Format Style:Integer|Decimal|Stacked", "-Compact Mode", "Biome Display", "Direction Heading", "#Text Color", "~Font Size:0.5:2:1", "Shadow Effect", "~Background Opacity:0:1:0.4");
        a(1, "F3 Display Mod", "-Hide Default F3 Screen", "Section System", "Section Game", "Section World", "Section Network", "Clean Layout", "~Scale Multiplier:0.5:2:1", "-Locked Screen Position");
        a(1, "Fog Customizer", "Clear Water Fog", "~Distance Fog Starting Point:0:1:0.5", "~Lava Fog Density:0:1:0.5", "-Sky Fog Color Overlay", "#Fog Color=A0C8FF", "-Toggle Blindness Fog");
        a(1, "FOV Changer", "Dynamic FOV Toggle", "~Sprint FOV Multiplier:0:2:1", "~Speed Potion FOV Multiplier:0:2:1", "~Slowness FOV Multiplier:0:2:1", "~Static FOV Cap:0.5:1.5:1.5");
        a(1, "Frames Per Second (FPS) Display", "Show FPS Text", "~Update Interval (MS):50:2000:250", "#Text Color", "~Background Transparency:0:1:0.5", "~Border Width:0:4:1");
        a(1, "Lighting Mod / Fullbright", "~Brightness Level:100:10000:1000", "Smooth Light Level Transition", "-Night Vision Toggle");
        a(1, "Memory Usage", "Display Allocated RAM", "Max RAM Metric", "Percentage Output", "~Color Warning Threshold:10:100:85");
        a(1, "Zoom", "~Scroll Wheel Zoom Factor:1.5:30:4", "Smooth Camera Interpolation", "-Cine Camera Toggle");
        // ---- Interface & QoL ----
        a(2, "3D Skins", "~Layer 2 Extrusion Thickness:0:2:1", "Paperdoll Model On-screen", "Cape Physics", "Hat Layer Render", "Self-Model View in HUD");
        a(2, "Better Sounds", "Mute Ambient Loops", "~Custom Footstep Balance:0:1:0.5", "-Explanatory Subtitles", "~Weather Volume:0:1:1", "~Players Volume:0:1:1", "~Items Volume:0:1:1");
        a(2, "Boss Bar", "-Hide Boss Bar", "#Custom Text Color", "#Custom Health Bar Color=FF55FF", "~Bar Scale:0.5:2:1", "Lock Position to Top");
        a(2, "Chat", "Unlimited Chat History", "~Chat Background Transparency:0:1:0.5", "-Custom Font Rendering", "Anti-Spam Message Stacking", "Clear Chat Button", "Mentions Alerts");
        a(2, "Continuity / Connected Textures", "Connect Glass", "Connect Sandstone", "Connect Bookshelves", "@Processing:Fast|Fancy", "-Border Texture Overlap");
        a(2, "Custom Animations", "@Eating Style:Vanilla|1.7|Smooth", "~Block Animation Delay:0:500:0", "Sword Sweep Effects", "-Left Hand Mirroring", "~Swing Velocity Modifier:0.5:2:1");
        a(2, "Direction HUD", "@Style:Compass Bar|Simple Text", "Show Degrees", "#Color Theme", "Marker Visibility", "~Horizontal Screen Span:100:400:200");
        a(2, "Fire Height", "~Fire Texture Vertical Offset:-100:0:-20", "~Opacity Level:0:1:1", "-Custom Fire Texture Override");
        a(2, "Freelook / Snaplook", "@View Mode:360 Orbit|Snaplook", "-Invert Axis", "@Key Action:Hold|Toggle", "~Custom Restrict Angle:0:180:180");
        a(2, "Hotbar Customizer", "-Vertical Layout Toggle", "~Hotbar Scale:0.5:2:1", "~Slot Spacing:0:10:0", "#Selected Box Outline Color", "-Hidden Item Slots");
        a(2, "Inventory HUD", "~Grid Size Columns:1:9:9", "Item Count Text", "Durability Bars on HUD Items", "~Opacity:0:1:0.6", "@Screen Dock Location:Top Left|Top Right|Bottom Left|Bottom Right");
        a(2, "Item Customizer", "~Main Hand Scale:0.5:2:1", "~Off-Hand Scale:0.5:2:1", "~Swing Translation X:-1:1:0", "~Swing Translation Y:-1:1:0", "~Swing Translation Z:-1:1:0", "~Rotation Angle Offset:-180:180:0");
        a(2, "Item Physics", "~3D Spin Rotation Speed:0:5:1", "~Rest Angle:0:90:90", "~Physics Rate:0.5:3:1", "~Bounce Factor on Impact:0:1:0.3");
        a(2, "Menu Blur", "~GUI Background Blur Intensity:0:10:5", "In-game Screen Fade", "Menu Contrast Adjustment");
        a(2, "NameTags", "~Scale Nameplates:0.5:2:1", "Show Health Value", "Display Ping", "-Custom Border", "Nameplate Shadow Toggle", "~Opacity Filter:0:1:0.25");
        a(2, "Pack Organizer", "Resource Pack Search Bar", "Sub-folder Categories", "Stack Ordering", "Preview Icon Grid");
        a(2, "Particle Changer", "#Custom Critical Particle Color=FF5555", "#Potion Effect Swirl Color=AA55FF", "~Particle Size Scalar:0.1:3:1", "~Max Particle Limit:100:10000:4000");
        a(2, "Saturation", "Food Bar Hunger Overlay", "Saturation Value Overlay", "-Numerical Values in Hotbar", "#Numerical Text Color");
        a(2, "Scoreboard", "-Hide Numbers Sidebar", "~Sidebar Scale:0.5:2:1", "Remove Red Text Background", "-Font Option", "-Hide Sidebar Entirely");
        a(2, "Screenshot Uploader", "Instant Imgur Upload", "Copy Link to Clipboard", "-Save Folder Directory Paths", "Auto-Save Notifications");
        a(2, "Scrollable Tooltips", "Horizontal Tooltip Scrolling", "Vertical Tooltip Scrolling", "~Max Width Constraint:100:600:300", "~Font Sizing:0.5:2:1");
        a(2, "Simple Voice Chat (SVC)", "~Proximity Volume:0:1:1", "~Microphone Volume Boost:0:3:1", "-Push-to-Talk Toggle", "Voice Icon HUD");
        a(2, "Smart Disconnect", "Confirmation Prompt Dialog", "-Reconnect Fast Key", "Back to Server List Override");
        a(2, "Tab Editor", "~Max Players Limit:20:200:80", "Clean Columns Grid", "Show Ping Numbers", "@Ping Icon Style:Bars|Dots|Numbers", "Compact Font");
        a(2, "Team View", "Team Member Coordinates Arrow", "Health Bar Tracking", "Distance Calculator", "#Border Accent Color");
        a(2, "Titles", "Custom Title/Subtitle Layout", "~Duration Adjuster:0.25:3:1", "-Hide Screen Warning Titles");
        a(2, "Waypoints", "#Waypoint Color Picker", "Distance Text Visibility", "~Beam Height:10:256:128", "In-World Map Icons", "Auto-Death Marker Creation");
        a(2, "Weather & Time Changer", "Constant Time", "~Time of Day:0:24000:6000", "@Weather Lock:Off|Clear|Rain|Thunder", "-Sky Tint Overlay", "#Sky Tint Color=3366FF", "~Sky Tint Opacity:0:0.5:0.15");
        a(2, "WorldEdit CUI", "#Grid Selection Line Color=FF5555", "~Selection Fill Opacity:0:1:0.2", "~Box Bounds Thickness:1:5:2", "Active Region Sync");
        // ---- Server & Game Mode ----
        a(3, "Hypixel Mods", "Auto GG", "-Auto TIP", "Level Head Display", "Guild Chat Formatting", "Friend Online Notifications", "-Auto Requeue");
        a(3, "Hypixel Bedwars", "Generator Timers HUD", "Target Overlay Checklist", "Quick Shop Layout Organizer", "-Height Limit Alarm");
        a(3, "Hypixel Skyblock", "Skill HUD Trackers", "Terminal Solver Assistance", "Melody Harp Tool", "Bazaar Live Calculators", "Dungeon Secret Waypoints");
        a(3, "Chest Profit Calculator", "Estimated Dungeon Chest Value", "Net Profit Metric", "~Price Refresh Interval (S):10:600:60", "Highlight Most Profitable");
        a(3, "Diana Sphinx Trivia Solver", "Automated Question Parsing", "Correct Answer Highlighter", "Sound Prompt Indicator");
        a(3, "Mage Beam Customizer", "~Beam Radius Scale:0.5:3:1", "#Custom RGBA Color Profile=55FFFF", "~Beam Trail Particle Count:0:100:20");
        a(3, "TierTagger", "Threat Rating Tag above Head", "Skill Tier Level Labels", "#Custom Rank Color Profile=FFAA00");
        a(3, "UHC Overlay", "Rescale Golden Apples", "~Golden Heads Scale:0.5:3:1", "Diamond Item Visual Enlargement", "-Ore Highlighter");
        a(3, "Replay Mod", "@Recording Resolution:720p|1080p|1440p", "@Keyframe Path Interpolation:Linear|Cubic", "Recording Indicator", "Auto-Save Path on Server Disconnect");
    }
}
