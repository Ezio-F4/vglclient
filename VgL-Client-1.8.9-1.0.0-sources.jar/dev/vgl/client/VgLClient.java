package dev.vgl.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.event.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

@Mod(modid = "vglclient", name = "VgL Client", version = "1.0.0", clientSideOnly = true, acceptedMinecraftVersions = "[1.8.9]")
public class VgLClient {
    public static final KeyBinding OPEN = new KeyBinding("Open Mod Menu", Keyboard.KEY_RSHIFT, "VgL Client");
    public static final KeyBinding ZOOM = new KeyBinding("Zoom", Keyboard.KEY_C, "VgL Client");
    final Minecraft mc = Minecraft.func_71410_x();

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        ClientRegistry.registerKeyBinding(OPEN);
        ClientRegistry.registerKeyBinding(ZOOM);
        Catalog.init();
        Config.load();
        MinecraftForge.EVENT_BUS.register(this);
        Runtime.getRuntime().addShutdownHook(new Thread() { public void run() { Config.save(); } });
    }

    @SubscribeEvent public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        boolean pressed = OPEN.func_151468_f();
        if (pressed && mc.field_71462_r == null && mc.field_71439_g != null) mc.func_147108_a(new ClickGui());
        for (Module m : Catalog.ALL) if (m.enabled) try { m.onTick(); } catch (Throwable t) { t.printStackTrace(); }
    }
    @SubscribeEvent public void onPre(RenderGameOverlayEvent.Pre e) {
        for (Module m : Catalog.ALL) if (m.enabled) try { m.onOverlayPre(e); } catch (Throwable t) { t.printStackTrace(); }
    }
    @SubscribeEvent public void onPost(RenderGameOverlayEvent.Post e) {
        if (e.type != RenderGameOverlayEvent.ElementType.ALL) return;
        Anim.tick();
        ScaledResolution sr = e.resolution;
        for (Module m : Catalog.ALL) if (m.enabled) try { m.onRender(sr, e.partialTicks); } catch (Throwable t) { t.printStackTrace(); }
    }
    @SubscribeEvent public void onFov(FOVUpdateEvent e) { for (Module m : Catalog.ALL) if (m.enabled) m.onFov(e); }
    @SubscribeEvent public void onMouse(MouseEvent e) {
        if (e.buttonstate) { if (e.button == 0) Impl.Clicks.add(true); if (e.button == 1) Impl.Clicks.add(false); }
        for (Module m : Catalog.ALL) if (m.enabled) m.onMouse(e);
    }
    @SubscribeEvent public void onChat(ClientChatReceivedEvent e) { for (Module m : Catalog.ALL) if (m.enabled) m.onChat(e); }
    @SubscribeEvent public void onAttack(AttackEntityEvent e) { for (Module m : Catalog.ALL) if (m.enabled) m.onAttack(e); }
}
