package dev.vgl.client;

import java.util.HashMap;
import java.util.Map;

/** Frame-rate independent exponential smoothing used for every UI animation. */
public class Anim {
    static final Map<Object, Float> m = new HashMap<Object, Float>();
    static long last = System.nanoTime();
    public static float dt = 0.016f;

    public static void tick() {
        long n = System.nanoTime(); float d = (n - last) / 1e9f;
        if (d > 0.002f) { dt = Math.min(d, 0.05f); last = n; }
    }
    public static float get(Object key, float target, float speed) { return get(key, target, speed, 0f); }
    public static float get(Object key, float target, float speed, float init) {
        Float v = m.get(key); if (v == null) v = init;
        v += (target - v) * (1f - (float) Math.exp(-speed * dt));
        m.put(key, v); return v;
    }
}
