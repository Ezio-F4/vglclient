package main

import (
	_ "embed"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"sync"
	"time"
)

//go:embed ui.html
var ui []byte

const (
	forgeVer = "1.8.9-11.15.1.2318-1.8.9"
	forgeID  = "1.8.9-forge1.8.9-11.15.1.2318-1.8.9"
	forgeURL = "https://maven.minecraftforge.net/net/minecraftforge/forge/" + forgeVer + "/forge-" + forgeVer + "-installer.jar"
)

var (
	mu       sync.Mutex
	logs     []string
	busy     bool
	lastPing = time.Now()
	pinged   bool
)

func logf(f string, a ...any) { mu.Lock(); logs = append(logs, fmt.Sprintf(f, a...)); mu.Unlock() }

func home() string {
	if runtime.GOOS == "windows" {
		return os.Getenv("APPDATA")
	}
	h, _ := os.UserHomeDir()
	return h
}
func mcDir() string   { return filepath.Join(home(), ".minecraft") }
func gameDir() string { return filepath.Join(home(), ".vgl-client") }
func exeDir() string  { e, _ := os.Executable(); return filepath.Dir(e) }

func findJava() string {
	g, _ := filepath.Glob(filepath.Join(mcDir(), "runtime", "*", "*", "*", "bin", "java*"))
	for _, p := range g {
		if filepath.Base(p) == "java.exe" || filepath.Base(p) == "java" {
			return p
		}
	}
	if p, err := exec.LookPath("java"); err == nil {
		return p
	}
	return ""
}

func findJar() string {
	for _, d := range []string{exeDir(), filepath.Join(exeDir(), "mods"), filepath.Join(exeDir(), "build", "libs")} {
		g, _ := filepath.Glob(filepath.Join(d, "VgL-Client*.jar"))
		if len(g) > 0 {
			return g[0]
		}
	}
	return ""
}

func exists(p string) bool { _, err := os.Stat(p); return err == nil }

func download(url, dest string) error {
	r, err := http.Get(url)
	if err != nil {
		return err
	}
	defer r.Body.Close()
	if r.StatusCode != 200 {
		return fmt.Errorf("HTTP %d", r.StatusCode)
	}
	f, err := os.Create(dest)
	if err != nil {
		return err
	}
	defer f.Close()
	_, err = io.Copy(f, r.Body)
	return err
}

func copyFile(src, dst string) error {
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	out, err := os.Create(dst)
	if err != nil {
		return err
	}
	defer out.Close()
	_, err = io.Copy(out, in)
	return err
}

func writeProfile(gb int) error {
	p := filepath.Join(mcDir(), "launcher_profiles.json")
	root := map[string]any{}
	if b, err := os.ReadFile(p); err == nil {
		_ = json.Unmarshal(b, &root)
	}
	profs, _ := root["profiles"].(map[string]any)
	if profs == nil {
		profs = map[string]any{}
	}
	now := time.Now().UTC().Format("2006-01-02T15:04:05.000Z")
	profs["vgl-client"] = map[string]any{
		"name": "VgL Client", "type": "custom", "created": now, "lastUsed": now,
		"lastVersionId": forgeID, "gameDir": gameDir(), "icon": "Furnace",
		"javaArgs": fmt.Sprintf("-Xmx%dG -XX:+UseG1GC", gb),
	}
	root["profiles"] = profs
	if _, ok := root["version"]; !ok {
		root["version"] = 3
	}
	b, _ := json.MarshalIndent(root, "", "  ")
	return os.WriteFile(p, b, 0644)
}

func currentRAM() int {
	b, err := os.ReadFile(filepath.Join(mcDir(), "launcher_profiles.json"))
	if err != nil {
		return 2
	}
	var root map[string]any
	_ = json.Unmarshal(b, &root)
	if ps, ok := root["profiles"].(map[string]any); ok {
		if v, ok := ps["vgl-client"].(map[string]any); ok {
			var n int
			fmt.Sscanf(fmt.Sprint(v["javaArgs"]), "-Xmx%dG", &n)
			if n > 0 {
				return n
			}
		}
	}
	return 2
}

func install(gb int) {
	defer func() { mu.Lock(); busy = false; mu.Unlock() }()
	logf("Checking Minecraft folder...")
	if !exists(filepath.Join(mcDir(), "versions", "1.8.9", "1.8.9.jar")) {
		logf("ERROR: Minecraft 1.8.9 not found. Open the official Minecraft Launcher, run vanilla 1.8.9 once, then press Install again.")
		return
	}
	if !exists(filepath.Join(mcDir(), "versions", forgeID)) {
		java := findJava()
		if java == "" {
			logf("ERROR: no Java found. Install Java 8 or run the official launcher once.")
			return
		}
		tmp := filepath.Join(os.TempDir(), "forge-installer.jar")
		logf("Downloading Forge %s...", forgeVer)
		if err := download(forgeURL, tmp); err != nil {
			logf("ERROR downloading Forge: %v", err)
			return
		}
		logf("Installing Forge (this takes a moment)...")
		c := exec.Command(java, "-jar", tmp, "--installClient", mcDir())
		c.Dir = mcDir()
		hide(c)
		out, err := c.CombinedOutput()
		if err != nil || !exists(filepath.Join(mcDir(), "versions", forgeID)) {
			logf("ERROR: Forge install failed: %v\n%s", err, string(out))
			return
		}
		logf("Forge installed.")
	} else {
		logf("Forge already installed.")
	}
	os.MkdirAll(filepath.Join(gameDir(), "mods"), 0755)
	if jar := findJar(); jar != "" {
		if err := copyFile(jar, filepath.Join(gameDir(), "mods", filepath.Base(jar))); err != nil {
			logf("ERROR copying mod: %v", err)
			return
		}
		logf("VgL Client mod installed: %s", filepath.Base(jar))
	} else {
		logf("WARNING: VgL-Client jar not found next to the launcher. Put VgL-Client-*.jar beside this .exe and press Install again.")
	}
	if err := writeProfile(gb); err != nil {
		logf("ERROR writing profile: %v", err)
		return
	}
	logf("Profile 'VgL Client' ready. Press PLAY.")
}

func launch() {
	cands := []string{
		filepath.Join(os.Getenv("ProgramFiles(x86)"), "Minecraft Launcher", "MinecraftLauncher.exe"),
		filepath.Join(os.Getenv("ProgramFiles"), "Minecraft Launcher", "MinecraftLauncher.exe"),
		filepath.Join(os.Getenv("LOCALAPPDATA"), "Programs", "Minecraft Launcher", "MinecraftLauncher.exe"),
	}
	for _, c := range cands {
		if exists(c) {
			cmd := exec.Command(c)
			if cmd.Start() == nil {
				logf("Minecraft Launcher started - choose the 'VgL Client' profile and press Play.")
				return
			}
		}
	}
	cmd := exec.Command("cmd", "/c", "start", "", "minecraft:")
	hide(cmd)
	if cmd.Start() == nil {
		logf("Minecraft Launcher started - choose the 'VgL Client' profile and press Play.")
		return
	}
	logf("ERROR: could not find the Minecraft Launcher. Install it from minecraft.net.")
}

func jsonOut(w http.ResponseWriter, v any) { w.Header().Set("Content-Type", "application/json"); json.NewEncoder(w).Encode(v) }

func main() {
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) { w.Header().Set("Content-Type", "text/html; charset=utf-8"); w.Write(ui) })
	mux.HandleFunc("/api/ping", func(w http.ResponseWriter, r *http.Request) { mu.Lock(); lastPing = time.Now(); pinged = true; mu.Unlock(); w.Write([]byte("ok")) })
	mux.HandleFunc("/api/status", func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		l := append([]string{}, logs...)
		b := busy
		mu.Unlock()
		jar := findJar()
		jsonOut(w, map[string]any{
			"vanilla": exists(filepath.Join(mcDir(), "versions", "1.8.9", "1.8.9.jar")),
			"forge":   exists(filepath.Join(mcDir(), "versions", forgeID)),
			"jar":     filepath.Base(jar), "hasJar": jar != "", "java": findJava() != "",
			"ram": currentRAM(), "busy": b, "log": l,
		})
	})
	mux.HandleFunc("/api/install", func(w http.ResponseWriter, r *http.Request) {
		gb, _ := strconv.Atoi(r.URL.Query().Get("gb"))
		if gb < 1 {
			gb = 2
		}
		mu.Lock()
		if busy {
			mu.Unlock()
			return
		}
		busy = true
		mu.Unlock()
		go install(gb)
	})
	mux.HandleFunc("/api/ram", func(w http.ResponseWriter, r *http.Request) {
		gb, _ := strconv.Atoi(r.URL.Query().Get("gb"))
		if gb >= 1 && exists(filepath.Join(mcDir(), "launcher_profiles.json")) {
			_ = writeProfile(gb)
		}
	})
	mux.HandleFunc("/api/launch", func(w http.ResponseWriter, r *http.Request) { launch() })

	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		os.Exit(1)
	}
	url := "http://" + ln.Addr().String()
	openWindow(url)
	go func() { // exit when the window is closed
		for {
			time.Sleep(2 * time.Second)
			mu.Lock()
			gone := pinged && time.Since(lastPing) > 8*time.Second
			never := !pinged && time.Since(lastPing) > 40*time.Second
			mu.Unlock()
			if gone || never {
				os.Exit(0)
			}
		}
	}()
	http.Serve(ln, mux)
}

func openWindow(url string) {
	for _, e := range []string{
		filepath.Join(os.Getenv("ProgramFiles(x86)"), "Microsoft", "Edge", "Application", "msedge.exe"),
		filepath.Join(os.Getenv("ProgramFiles"), "Microsoft", "Edge", "Application", "msedge.exe"),
		filepath.Join(os.Getenv("ProgramFiles"), "Google", "Chrome", "Application", "chrome.exe"),
		filepath.Join(os.Getenv("ProgramFiles(x86)"), "Google", "Chrome", "Application", "chrome.exe"),
	} {
		if exists(e) {
			c := exec.Command(e, "--app="+url, "--window-size=900,580", "--user-data-dir="+filepath.Join(os.TempDir(), "vgl-launcher-profile"))
			if c.Start() == nil {
				return
			}
		}
	}
	c := exec.Command("rundll32", "url.dll,FileProtocolHandler", url)
	hide(c)
	_ = c.Start()
}
