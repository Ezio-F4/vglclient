module vglauncher

go 1.22
