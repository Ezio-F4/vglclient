VgL Launcher
1. Build the mod from VgL-Client-source.zip (see its README) -> VgL-Client-1.8.9-1.0.0.jar
2. Put that .jar in the same folder as VgL-Launcher.exe
3. Run the official Minecraft Launcher once with vanilla 1.8.9 (so the game files exist), close it
4. Run VgL-Launcher.exe -> Install / Update -> PLAY (opens the Minecraft Launcher on the "VgL Client" profile list)
Rebuild the exe: cd launcher-source && GOOS=windows GOARCH=amd64 go build -ldflags "-H=windowsgui -s -w" -o VgL-Launcher.exe .
